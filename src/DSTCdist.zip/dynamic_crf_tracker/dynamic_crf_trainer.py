
import os, cPickle, itertools
from copy import deepcopy
from datetime import datetime
from pprint import pprint
import numpy as np
from owlqn import fmin_owlqn
from domain.domain_tasks import concepts as nodes
from dynamic_crf_tracker import DynamicCRFTracker
from dialog_core.dialog_datatype import UserAction, InputHypothesis, SystemAction

# Need to split actions for from, to

def generate_system_acts(outputs, tracker):
    if 'dialog-acts' not in outputs or outputs['dialog-acts'] == []:
        return []

    system_acts = []
    for act in outputs['dialog-acts']:
        system_acts.append(SystemAction(act['act'], dict(act['slots'])))
        
    return system_acts
    

def generate_input_hyps(inputs, tracker):
    slu_hyps = inputs
    
    input_hyps = []
    for slu_hyp in slu_hyps:
        if slu_hyp['score'] <= 0.0:
            continue
        
        user_acts = []
        for act_hyp in slu_hyp['slu-hyp']:
            user_acts.append(UserAction(act_hyp['act'], dict(act_hyp['slots'])))
        
        input_hyps.append(InputHypothesis(user_acts, slu_hyp['score']))
        
    input_hyps.sort(key=lambda x: x.conf_score, reverse=True)

    return input_hyps


def generate_labels(labels, system_acts, tracker):
    true_user_acts = []
    false_user_acts = []
    
    for label in labels:
        if label['label']:
            true_user_acts.append(UserAction('inform', dict(label['slots'])))
        else:
            false_user_acts.append(UserAction('inform', dict(label['slots'])))
    

    return (true_user_acts, false_user_acts)


def generate_dataset(json, json_root, dataset, prior_model_path=None, feature_extraction=True):
    from dstc.dataset_walker import dataset_walker
    
    tracker = DynamicCRFTracker(nodes, prior_model_path=prior_model_path)
    
    sessions = dataset_walker(json, json_root, labels=True)    
        
    data = []
    for session in sessions:
        tracker.init_tracker_state()
        query_restarted = False
        for turn_index, (log_turn, label_turn) in enumerate(session):
            if log_turn['restart'] == True:
                tracker.init_tracker_state()
            system_acts = generate_system_acts(log_turn['output'], tracker)
            input_hyps = generate_input_hyps(log_turn['input']['live']['slu-hyps'], tracker)
            labels = generate_labels(label_turn['slu-labels'], system_acts, tracker)
            tracker.update_tracker_state(system_acts, input_hyps, labels, feature_extraction=feature_extraction)
            data.append(deepcopy(tracker.get_tracker_state()))
            if log_turn['restart'] == True:
                if not query_restarted:
                    data[-2]['phase'] = 'FIRST_QUERY_END'
                    query_restarted = True
                data[-1]['phase'] = 'RESTART'
            else:
                data[-1]['phase'] = 'CONTINUE'
        if not query_restarted:
            data[-1]['phase'] = 'FIRST_QUERY_END'

    cPickle.dump(data, open(dataset, 'wb'))


def generate_prior_model(model_path, datasets, threshold=1.0):
    global nodes
    
#    tracker = DynamicCRFTracker(nodes)
    
    for dataset in datasets:
        if not os.path.exists(dataset):
            print 'No file exists:', dataset
            return
    
        states = cPickle.load(open(dataset, 'r'))
        
    priors = {}
    for node in nodes:
        priors[node] = {}

    for state in states:
        if state['phase'] != 'FIRST_QUERY_END':
            continue
        for node in nodes:
            for label in state['label'][node]:
                if label == 'None':
                    continue
                
                # For unsupervised training 
                if state['label-conf-score'][node] < threshold:
                    continue
                
                # For normalization of stop names between different datasets
                # ex, forbes and murray vs. forbes,murray
                label = label.replace(',', ' and ')
                
                if label not in priors[node]:
                    priors[node][label] = 1.0
                else:
                    priors[node][label] += 1.0
    
    with open(model_path, 'w') as model:
        for node in nodes:
            model.write('>>%s\n'%node)
            items = priors[node].items()
            items.sort(key=lambda x: x[1], reverse=True)
            for item in items:
                model.write(':'.join([str(x) for x in item]) + '\n')
        model.close()


def get_prior_param_index(tracker):
    prior_param_index = []

    for node in tracker.nodes:
        for feat in tracker.feat_to_paramidx[node].keys():
            if feat.startswith('prior-level-5') or\
            feat.startswith('prior-level-6') or\
            feat.startswith('prior-level-7') or\
            feat.startswith('prior-level-8') or\
            feat.startswith('prior-level-9'):
                prior_param_index.append(tracker.feat_to_paramidx[node][feat])

    print 'prior_param_index'
    print sorted(prior_param_index)
    return sorted(prior_param_index)


def get_active_param_index(tracker):
    active_features = ['none-bias', 'bias',
                       'open-conf-level', 'cohere-conf-level', 'nocohere-conf-level',
                       'prior-level', 'canthelp', 'max-score-level',
                       'impl-affirm',
                       'affirm-level', 'negate-level', 'accumulated-score']
    
    active_param_index = []

    for node in nodes:
        for feat in tracker.feat_to_paramidx[node].keys():
            if feat.find('level') > -1 or feat.find('rank') > -1:
                norm_feat = '-'.join(feat.split('-')[:-1])
            else:
                norm_feat = feat
            if norm_feat in active_features:
                active_param_index.append(tracker.feat_to_paramidx[node][feat])


    print 'active_param_index'
    print sorted(active_param_index)
    return sorted(active_param_index)
    

def get_empirical_expectation(example):
    emp_exp = np.array([])
    
    # take the feature vector associated with the true label
    node_feat_exp = {}
    for node in nodes: # parameter tying across all nodes 
        try:
            if example['label'][node] == []:
                labels = ['None']
            else:
                labels = example['label'][node]
                
            num_used_labels = 0
            for label in labels:
                if node not in node_feat_exp:
                    node_feat_exp[node] = np.zeros_like(example['features'][node]['None'], dtype=np.dtype('Float64'))
                    
                node_feat_exp[node] += example['features'][node][label]
                num_used_labels += 1
                    
            if num_used_labels > 0:
                node_feat_exp[node] /= 1.0 * num_used_labels
                
        except KeyError, e:
            pass
        
    
    for node in nodes:
        emp_exp = np.concatenate([emp_exp, node_feat_exp[node]])
            
    return emp_exp

    
def get_model_expectation(example, marginals, verbose=False):
    mod_exp = np.array([])
    
    # take the expectation of the feature vector associated with each configuration w.r.t. marginals  
    node_feat_exp = {}
    for node in nodes:
        for val in example['observation'][node]['values']:
            try:
                if node not in node_feat_exp:
                    node_feat_exp[node] = np.zeros_like(example['features'][node]['None'], dtype=np.dtype('Float64'))
                
                node_feat_exp[node] += example['features'][node][val] * marginals[node][val]
            
            except KeyError,e:
                print 'get_model_expectation'
                print example['session']
                print e
                pass
        
    for node in nodes:
        mod_exp = np.concatenate([mod_exp, node_feat_exp[node]])

    return mod_exp


def invalid_example(example, prev_example):
    if prev_example and example['observation'] == prev_example['observation']:
        print 'same example'
        return True
    
    for node in nodes:
        for label in example['label'][node]:
            if label not in example['observation'][node]['values']:
                return True
    return False
                           
    
def train_batch(model_path, datasets, RW=3.0, prior_RW=10.0, adapt=False, adapt_RW=5.0):
    training_examples = []
    for dataset in datasets:
        if not os.path.exists(dataset):
            print 'No file exists:', dataset
            return
    
        training_examples.extend(cPickle.load(open(dataset, 'r')))
    
    tracker = DynamicCRFTracker(nodes)
    
    def NLL_grad(active_params, **args):
        params = args['params']
        init_params = args['init_params']
        active_param_index = args['active_param_index']
        params[active_param_index] = active_params

        gradients = np.zeros_like(active_params, dtype=np.dtype('Float64'))

        prev_ex = None
        for i, ex in enumerate(training_examples):
            if invalid_example(ex, prev_ex):
                continue
            prev_ex = ex
            
            # compute marginals and partition function
            marginals, zval, reps = tracker.get_marginals_and_partition(ex, params)

            # compute a gradient
            # -(E_empirical[feature] - E_model[feature])
            emp_exp = get_empirical_expectation(ex)
            mod_exp = get_model_expectation(ex, marginals)
            gradients -= (emp_exp - mod_exp)[active_param_index]
        
        if adapt:
            # L2 regularization
            gradients += 2 * adapt_RW * (params[active_param_index] - init_params[active_param_index]) 
            
        return gradients
                
    def NLL_eval(active_params, **args):
        params = args['params']
        init_params = args['init_params']
        active_param_index = args['active_param_index']
        params[active_param_index] = active_params
        
        NLL = 0.0
        prev_ex = None
        for i, ex in enumerate(training_examples):
            if invalid_example(ex, prev_ex):
                continue
            prev_ex = ex
            
            # compute marginals and partition function
            marginals, zval, reps = tracker.get_marginals_and_partition(ex, params)
            
            # accumulate log-likelihoods
            NLL -= tracker.get_log_likelihood(ex, params, zval)
       
        if adapt:
            # L2 regularization
            NLL += adapt_RW * np.sum(np.power(params[active_param_index] - init_params[active_param_index], 2)) 

        
        return NLL
        
    # if this part can generalize across models
    # a separate trainer class should be designed
    params = None
    try:
        params = cPickle.load(open(model_path, 'rb'))
        defined_params = tracker.get_parameters()
        if len(params) < len(defined_params):
            defined_params[:len(params)] = params[:]
            params = defined_params
    except:
        params = tracker.get_parameters()
    params = tracker.get_parameters()
    pprint(params)
    
    init_params = deepcopy(params)
    active_param_index = get_active_param_index(tracker)
    prior_param_index = get_prior_param_index(tracker)
    
    if adapt:
        pprint(init_params)

    Cvec = np.ones_like(params) * RW
    Cvec[prior_param_index] = prior_RW
    active_params = params[active_param_index]
    active_Cvec = Cvec[active_param_index]
     
    print 'Number of active params: %d'%len(active_params)
    print 'Number of total params: %d'%len(params)
    print datetime.now()

    active_params,fval,gfk,func_calls,grad_calls,warnflag = fmin_owlqn(f=NLL_eval, x0=active_params, fprime=NLL_grad,
                                                                       args={'params': params, 'active_param_index': active_param_index, 'init_params': init_params},
                                                                       Cvec=active_Cvec, gtol=1e0, ftol=1e-1, maxiter=80, full_output=1)
    
    params[active_param_index] = active_params
    
    pprint(params)
    print fval
    print func_calls
    print grad_calls
    print datetime.now()
    cPickle.dump(params, open(model_path, 'wb'))


def dump_parameters(model_path, unary=False):
    tracker = DynamicCRFTracker(nodes)
    
    params = cPickle.load(open(model_path, 'rb'))
    
    for node in tracker.nodes:
        feat_dict = tracker.feat_to_paramidx[node]
        for k in sorted(feat_dict.keys()):
            print node, k, params[feat_dict[k]]
            
    for edge in tracker.edges:
        feat_dict = tracker.feat_to_paramidx[edge]
        for k in sorted(feat_dict.keys()):
            print edge,k,params[feat_dict[k]]
