
from pprint import pprint
import numpy as np
from copy import deepcopy


class TRW(object):
    def __init__(self):
        super(TRW, self).__init__()
        np.seterr(all='raise')
        self.damp = 0.5
        self.conv_thresh = 1e-6
        self.max_iter = 1000


    def get_marginals_and_partition(self, model):
        try:        
            ptnt = deepcopy(model['potential'])
            
            nbrs = {}
            rho = {}            
            for node in model['nodes']:
                nbrs[node] = [edge[1] for edge in model['edges'] if edge[0] == node] +\
                [edge[0] for edge in model['edges'] if edge[1] == node]
                rho[node] = [model['rho'][edge] for edge in model['edges'] if edge[0] == node] +\
                [model['rho'][edge] for edge in model['edges'] if edge[1] == node]
                
            # re-scale edge potentials
            for edge in model['edges']:
                node1, node2 = edge
                edge_ptnt = ptnt['edges'][edge]
                for val1 in model['values'][node1]:
                    for val2 in model['values'][node2]:
                        edge_ptnt[(val1, val2)] = np.power(edge_ptnt[(val1, val2)], 1.0 / model['rho'][edge])
            
            # initialize marginal structures
            node_mrg = {}    
            for node in model['nodes']:
                node_mrg[node] = {}
                for val in model['values'][node]:
                    node_mrg[node][val] = 0.0
            
            edge_mrg = {}            
            for edge in model['edges']:
                edge_mrg[edge] = {}
                node1, node2 = edge
                for val1 in model['values'][node1]:
                    for val2 in model['values'][node2]:
                        edge_mrg[edge][(val1, val2)] = 0.0
    
            # initialize message
            n = {}
            for node in model['nodes']:
                n[node] = {}
                for val in model['values'][node]: 
                    n[node][val] = 1.0
    
            m = {}
            for node in model['nodes']:
                m[node] = {}
                for nbr in nbrs[node]:
                    m[node][nbr] = {}
                    for val1 in model['values'][nbr]:
                        m[node][nbr][val1] = 1.0
            
            for reps in range(self.max_iter):
                # compute n[node] and m[from][to]
                for node in model['nodes']:
                    if model['active'][node] == False:
                        continue
                    node_ptnt = ptnt['nodes'][node]
                    # compute n[node]
                    for val in model['values'][node]:
                        n[node][val] = 1.0 
                        for k, nbr in enumerate(nbrs[node]):
                            n[node][val] *= np.power(m[nbr][node][val], rho[node][k]) # check its own potential
                    # compute m[from][to]
                    for nbr in nbrs[node]:
                        reversed = True if (node, nbr) in model['edges'] else False
                        sum = 0.0
                        for val1 in model['values'][nbr]:
                            m[node][nbr][val1] = 0.0
                            edge_ptnt = ptnt['edges'][(node, nbr)] if reversed else ptnt['edges'][(nbr, node)]
                            for val2 in model['values'][node]:
                                index = (val2, val1) if reversed else (val1, val2)
                                m[node][nbr][val1] += edge_ptnt[index] * node_ptnt[val2] * n[node][val2] / m[nbr][node][val2]
                            sum += m[node][nbr][val1]
                            
                        # normalize the message
                        for val1 in model['values'][nbr]:
                            if sum == 0.0:
                                m[node][nbr][val1] = 1.0 / len(model['values'][nbr])
                            else:                                                          
                                m[node][nbr][val1] /= sum
            
                
                # compute node marginals
                prev_node_mrg = deepcopy(node_mrg)
                conv = 0.0
                for node in model['nodes']:
                    if model['active'][node] == False:
                        continue
                    node_ptnt = ptnt['nodes'][node]
                    sum = 0.0
                    for val in model['values'][node]:
                        node_mrg[node][val] = n[node][val] * node_ptnt[val]
                        sum += node_mrg[node][val]
                    # normalize the marginal
                    for val in model['values'][node]:
                        if sum == 0.0:
                            node_mrg[node][val] = 1.0 / len(model['values'][node])
                        else:
                            node_mrg[node][val] /= sum
                        if prev_node_mrg != {}:
                            conv = max(conv, abs(prev_node_mrg[node][val] - node_mrg[node][val]))
                        else:
                            conv = 1e10
                        
                # compute edge marginals
                for edge in model['edges']:
                    edge_ptnt = ptnt['edges'][edge]
                    node1,node2 = edge
                    node1_ptnt = ptnt['nodes'][node1]
                    node2_ptnt = ptnt['nodes'][node2]
                    n_node1 = n[node1]
                    n_node2 = n[node2]
                    m_node1_node2 = m[node1][node2]
                    m_node2_node1 = m[node2][node1]
                    sum = 0.0
                    for val1 in model['values'][node1]:
                        for val2 in model['values'][node2]:
                            edge_mrg[edge][(val1,val2)] = edge_ptnt[(val1,val2)] * node1_ptnt[val1] * node2_ptnt[val2] *\
                            n_node1[val1] * n_node2[val2] / m_node1_node2[val2] / m_node2_node1[val1]
                            sum += edge_mrg[edge][(val1,val2)]
                    # normalize the marginal
                    for val1 in model['values'][node1]:
                        for val2 in model['values'][node2]:
                            if sum == 0.0:
                                edge_mrg[edge][(val1, val2)] = 1.0 / (len(model['values'][node1]) * len(model['values'][node2]))
                            else:
                                edge_mrg[edge][(val1, val2)] /= sum
                
                if conv <= self.conv_thresh:
                    break
            
            # compute partition function
            node_theta_mrg_prdt = 0.0
            for node in model['nodes']:
                if model['active'][node] == False:
                    continue
                node_log_ptnt = model['log_ptnt']['nodes'][node]
#                node_ptnt = ptnt['nodes'][node]
                for val in model['values'][node]:
                    if node_mrg[node][val] > 0:
#                        node_theta_mrg_prdt += np.log(node_ptnt[val]) * node_mrg[node][val]
                        node_theta_mrg_prdt += node_log_ptnt[val] * node_mrg[node][val]
                        
            edge_theta_mrg_prdt = 0.0
            for edge in model['edges']:
                edge_log_ptnt = model['log_ptnt']['edges'][edge] # note that we need original potential
#                edge_ptnt = model['potential']['edges'][edge] # note that we need original potential
                node1, node2 = edge
                for val1 in model['values'][node1]:
                    for val2 in model['values'][node2]:
                        if edge_mrg[edge][(val1, val2)] > 0:
#                            edge_theta_mrg_prdt += np.log(edge_ptnt[(val1, val2)]) * edge_mrg[edge][(val1, val2)]
                            edge_theta_mrg_prdt += edge_log_ptnt[(val1, val2)] * edge_mrg[edge][(val1, val2)]
    
            sum_node_h = 0.0
            for node in model['nodes']:
                if model['active'][node] == False:
                    continue
                for val in model['values'][node]:
                    if node_mrg[node][val] > 0:
                        sum_node_h -= (1.0 - np.sum(rho[node])) * node_mrg[node][val] * np.log(node_mrg[node][val])
    
            sum_edge_h = 0.0
            for edge in model['edges']:
                node1, node2 = edge
                for val1 in model['values'][node1]:
                    for val2 in model['values'][node2]:
                        if edge_mrg[edge][(val1, val2)] > 0:
                            sum_edge_h -= model['rho'][edge] * edge_mrg[edge][(val1, val2)] * np.log(edge_mrg[edge][(val1, val2)])
    
            log_partition = node_theta_mrg_prdt + edge_theta_mrg_prdt + sum_node_h + sum_edge_h
            
            node_mrg.update(edge_mrg)
            
            return node_mrg, log_partition, reps
        
        except FloatingPointError as e:
            print 'node_ptnt'
            pprint(node_ptnt)
            print 'dm'
            pprint(model)
            print 'n'
            pprint(n)
            print 'm'
            pprint(m)
            raise RuntimeError
 
        
    def get_log_likelihood(self, model, labels, zval=None):
        if zval == None:
            marginals, zval = self.get_marginals_and_partition(model)
        
        if np.isinf(zval):
            return np.finfo(np.float32).min
        
        ptnt = model['potential']
        log_ptnt = model['log_ptnt']
        unnorm_log_ptnt = 0.0
        for node in model['nodes']:
            if model['active'][node] == False:
                continue
            try:
                if labels[node] == []:
                    _labels = ['None']
                else:
                    _labels = labels[node]
                unnorm_log_ptnt_multi_label = 0.0
                for label in _labels:
                    unnorm_log_ptnt_multi_label += log_ptnt['nodes'][node][label]
                unnorm_log_ptnt_multi_label /= (1.0 * len(_labels))
                unnorm_log_ptnt += unnorm_log_ptnt_multi_label
            except KeyError,e:
#                print e
                return 0.0
                pass

        for edge in model['edges']:
            node1,node2 = edge
            try:
                if labels[node1] == []:
                    labels1 = ['None']
                else:
                    labels1 = labels[node1]
                if labels[node2] == []:
                    labels2 = ['None']
                else:
                    labels2 = labels[node2]
                unnorm_log_ptnt_multi_label = 0.0
                for label1 in labels1:
                    for label2 in labels2:
                        unnorm_log_ptnt_multi_label += log_ptnt['edges'][edge][(label1,label2)]
                unnorm_log_ptnt_multi_label /= (1.0 * len(labels1) * len(labels2))
                unnorm_log_ptnt += unnorm_log_ptnt_multi_label
            except KeyError,e:
#                print e
                return 0.0
                pass
        
        try:
            return unnorm_log_ptnt - zval
        except:
            for node in model['nodes']:
                print ptnt['nodes'][node][labels[node]]
                print np.log(ptnt['nodes'][node][labels[node]])
            
            print unnorm_log_ptnt
            print zval    

