
import numpy as np
from math import exp, floor
from copy import deepcopy
import cPickle
from pprint import pprint, pformat
import logging
from trw import TRW

app_logger = logging.getLogger('DynamicCRFTracker')

    
class DynamicCRFTracker(object):
    def __init__(self, nodes, edges=[], model_path=None, prior_model_path=None):

        #=======================================================================
        # Graphical model
        #=======================================================================
        self.nodes = nodes
        self.tied_nodes = nodes
        self.edges = edges
        
        #=======================================================================
        # Features and Corresponding parameters
        #=======================================================================
        self.feat_to_paramidx = {}
        self.node_paramidx = {}
        self.edge_paramidx = {}
        self.params = None
        self._define_parameters()
        self._load_model(model_path)
        
        #=======================================================================
        # Inference engine
        #=======================================================================
        self.inference_engine = TRW() 
        self.default_rho = float(2/3)
        
        #=======================================================================
        # Etc
        #=======================================================================
        self.priors = None
        self._load_priors(prior_model_path)
        self.prior_thlds = 0.1
        self.nbest_max = 100
        self.max_level = 10
        
        self.init_tracker_state()  

    
    def _load_model(self, model_path):
        if model_path:
            self.params = cPickle.load(open(model_path, 'rb'))
    

    def _load_priors(self, model_path):
        if model_path:
            self.priors = {'nodes':{}, 'max-freq-nodes':{}}
            
            with open(model_path, 'r') as model:
                for line in model:
                    if line.startswith('>>'):
                        node = line[2:].strip()
                        self.priors['nodes'][node] = {}
                    else:
                        self.priors['nodes'][node][line.split(':')[0]] = float(line.split(':')[1])
                for node in self.nodes:
                    items = self.priors['nodes'][node].items()
                    items.sort(key=lambda x: x[1], reverse=True)
                    print node
                    print '\n'.join([str(item) for item in items])
                    self.priors['max-freq-nodes'][node] = items[0][1]
                model.close()
            app_logger.info(pformat(self.priors))
    

    def init_tracker_state(self):
        # will convert dict to TrackerState class later 
        state = {}
        state['session'] = 'None'
        state['time'] = {}
        state['phase'] = 'INIT'
        
        #=======================================================================
        # Label information
        #=======================================================================
        state['label'] = {}
        state['label-conf-score'] = {}
        for node in self.nodes:
            state['label'][node] = []
            state['label-conf-score'][node] = 1.0

        #=======================================================================
        # Observation information
        #=======================================================================
        state['observation'] = {}
        for node in self.nodes:
            state['observation'][node] = {}
            state['observation'][node]['values'] = ['None']
            state['observation'][node]['instance'] = {'None': [{
                                            'score': 0.0,
                                            'rank': 0,
                                            'system-acts': [],
                                            'slots': None
                                            }]}
            state['observation'][node]['affirm'] = {'None': []}
            state['observation'][node]['negate'] = {'None': []}
            state['observation'][node]['impl-affirm'] = {'None': False}
#            state['observation'][node]['impl-affirm'] = {'None': 0.0}
            state['observation'][node]['canthelp'] = {'None': False}
        
        self.state = state


    def _define_parameters(self):
        # extract parameters
        # define parameter index
       
        num_params = 0
        
        for node in self.tied_nodes:
            node_start_paramidx = num_params
            self.feat_to_paramidx[node] = {}
            # base features            
            self.feat_to_paramidx[node]['none-bias'] = num_params
            num_params += 1
            self.feat_to_paramidx[node]['bias'] = num_params
            num_params += 1
            for level in range(0,10):
                self.feat_to_paramidx[node]['open-conf-level-%d'%(level)] = num_params
                num_params += 1
            for level in range(0,10):
                self.feat_to_paramidx[node]['cohere-conf-level-%d'%(level)] = num_params
                num_params += 1
            for level in range(0,10):
                self.feat_to_paramidx[node]['nocohere-conf-level-%d'%(level)] = num_params
                num_params += 1

            # canthelp feature
            self.feat_to_paramidx[node]['canthelp'] = num_params
            num_params += 1
            
            # features for explicit-affirmation
            for level in range(0,10):
                self.feat_to_paramidx[node]['affirm-level-%d'%(level)] = num_params
                num_params += 1
    
            # features for implicit-affirmation
            self.feat_to_paramidx[node]['impl-affirm'] = num_params
            num_params += 1
#            for level in range(0,10):
#                self.feat_to_paramidx[node]['impl-affirm-level-%d'%(level)] = num_params
#                num_params += 1
    
            # features for negation
            for level in range(0,10):
                self.feat_to_paramidx[node]['negate-level-%d'%(level)] = num_params
                num_params += 1
    
            # prior
            for level in range(0,10):
                self.feat_to_paramidx[node]['prior-level-%d'%(level)] = num_params
                num_params += 1
            
            # maximum score so far        
            for level in range(0,10):
                self.feat_to_paramidx[node]['max-score-level-%d'%(level)] = num_params
                num_params += 1
            
            # accumulated score
            self.feat_to_paramidx[node]['accumulated-score'] = num_params
            num_params += 1

            self.node_paramidx[node] = range(node_start_paramidx, num_params)
            
        self.params = np.zeros(num_params, dtype=np.dtype('Float64'))

    
    def get_parameters(self):
        return self.params
    
    
    def get_tracker_state(self):
        return self.state
    
    
    def update(self, system_act, input_hyps):
        self.update_tracker_state(system_act, input_hyps)
        return self.get_marginals_and_partition(self.state, self.params)
        
            
    def update_tracker_state(self, system_acts, input_hyps, labels=None, feature_extraction=True):
        self._update_observation_state(system_acts, input_hyps)
        if feature_extraction:
            self._update_feature_state()
        if labels:
            self._update_label_state(labels, input_hyps)
#        app_logger.info(pformat(self.state))        
        
    def _update_observation_state(self, system_acts, input_hyps):
        def _add_new_observation(state, val):
            state['observation'][node]['values'].append(val)
            state['observation'][node]['instance'][val] = []
            state['observation'][node]['affirm'][val] = []
            state['observation'][node]['negate'][val] = []
            state['observation'][node]['impl-affirm'][val] = False
#            state['observation'][node]['impl-affirm'][val] = 0.0
            state['observation'][node]['canthelp'][val] = False
            
        state = self.state
        
        # Loop for N-bests
        for nbest_index, input_hyp in enumerate(input_hyps):
            if nbest_index >= self.nbest_max:
                break

            # Loop for nodes; placed outer than the loop for user actions
            # in case we need confidence score calibration.
            for node in self.nodes:
                # Loop for user actions of an input hypothesis
                for user_act in input_hyp.user_acts:
                    # Handle inform
                    if user_act.act_type == 'inform' and user_act.has_relevant_arg(node):
                        val = user_act.serialize_args()
                        if val not in state['observation'][node]['values']:
                            _add_new_observation(state, val)
                        state['observation'][node]['instance'][val].append({
                            'score': input_hyp.conf_score,
                            'rank': nbest_index,
                            'system-acts': system_acts,
                            'slots': user_act.act_args,
                            })
                    # Handle affirm
                    elif user_act.act_type == 'affirm':
                        for system_act in system_acts:
                            if system_act.act_type == 'expl-conf' and system_act.has_relevant_arg(node):
                                val = system_act.serialize_args()
                                if val in state['observation'][node]['affirm']:
                                    state['observation'][node]['affirm'][val].append(input_hyp.conf_score)
                                else:
#                                    self.app_logger.info('%s is not a seen value'%val)
                                    pass
                                    # For DSTC datasets
#                                    arg_set = set(system_act.act_args.items())
#                                    for exist_val in state['observation'][node]['instance'].keys():
#                                        if exist_val != 'None' and\
#                                        arg_set.issuperset(set(state['observation'][node]['instance'][exist_val][0]['slots'].items())):
#                                            pprint(system_act.act_args)
#                                            pprint(state['observation'][node]['instance'][exist_val][0]['slots'])
#                                            _add_new_observation(state, val)
#                                            state['observation'][node]['affirm'][val].append(input_hyp.conf_score)
#                                            state['observation'][node]['instance'][val] = deepcopy(state['observation'][node]['instance'][exist_val])
#                                            for inst in state['observation'][node]['instance'][val]:
#                                                inst['slots'] = system_act.act_args
                                            
                    # Handle negate
                    elif user_act.act_type in ['negate', 'goback']:
                        for system_act in system_acts:
#                            if system_act.act_type in ['expl-conf', 'impl-conf'] and system_act.has_relevant_arg(node):
                            if system_act.act_type in ['expl-conf'] and system_act.has_relevant_arg(node):
                                val = system_act.serialize_args()
                                if val in state['observation'][node]['negate']:
                                    state['observation'][node]['negate'][val].append(input_hyp.conf_score)
                                else:
#                                    self.app_logger.info('%s is not a seen value'%val)
                                    pass
                
        # Handle impl-conf 
        for system_act in system_acts:
            if system_act.act_type == 'impl-conf':
                # We assume one argument for impl-conf
                for node in self.nodes:
                    if system_act.has_relevant_arg(node):
                        val = system_act.serialize_args()
                        
                        impl_negate = False
                        for nbest_index, input_hyp in enumerate(input_hyps):
                            if nbest_index >= self.nbest_max:
                                break
                            for user_act in input_hyp.user_acts:
                                if (user_act.act_type == 'inform' and user_act.has_relevant_arg(node)) or\
                                (user_act.act_type == 'negate'):
                                    impl_negate = True
                                    break
                            if impl_negate:
                                break
                        if not impl_negate:
                            state['observation'][node]['impl-affirm'][val] = True
                            
#                        state['observation'][node]['impl-affirm'][val] = 1.0
#                        for nbest_index, input_hyp in enumerate(input_hyps):
#                            if nbest_index >= self.nbest_max:
#                                break
#                            for user_act in input_hyp.user_acts:
#                                if (user_act.act_type == 'inform' and user_act.has_relevant_arg(node)) or\
#                                (user_act.act_type == 'negate'):
#                                    state['observation'][node]['impl-affirm'][val] = min(1.0 - input_hyp.conf_score, state['observation'][node]['impl-affirm'][val])
                        break
                else:
#                    self.app_logger.info('System action %s does not have a corresponding node'%str(system_act))
                    pass
                    
                                
        # Handle canthelp 
        for system_act in system_acts:
            if system_act.act_type.startswith('canthelp'):
                for node in self.nodes:
                    if system_act.has_relevant_arg(node):
                        state['observation'][node]['canthelp'][system_act.serialize_args()] = True


    def _update_feature_state(self):
        def _convert_score_to_level(max_level, score):
            score = max(0.0, score)
            level = floor(score * max_level)
            level = min(max_level - 1, level)
            return level
        
        state = self.state
        
        # node features
        vectors = {}
        feats = {}
        for node in self.nodes:
            vectors[node] = {}
            feats[node] = {}
            
            # For max-score feature
            val_with_max_score = None
            max_score = 0.0
            for val in state['observation'][node]['values']:
                feats[node][val] = {}
                
                max_level = self.max_level
                
                for level in range(0, max_level):
                    feats[node][val]['open-conf-level-%d'%level] = 0
                    feats[node][val]['cohere-conf-level-%d'%level] = 0
                    feats[node][val]['nocohere-conf-level-%d'%level] = 0

                for level in range(0, max_level):
                    feats[node][val]['affirm-level-%d'%level] = 0

                for level in range(0, max_level):
                    feats[node][val]['negate-level-%d'%level] = 0

                for level in range(0, max_level):
                    feats[node][val]['prior-level-%d'%level] = 0

#                for level in range(0, max_level):
#                    feats[node][val]['impl-affirm-level-%d'%level] = 0

                feats[node][val]['impl-affirm'] = 0
                feats[node][val]['canthelp'] = 0
                feats[node][val]['accumulated-score'] = 0
                feats[node][val]['none-bias'] = 1
                feats[node][val]['bias'] = 1

                if val == 'None':
                    continue

                # Generating inform act confidence related features 
                for inst in state['observation'][node]['instance'][val]:
                    level = _convert_score_to_level(max_level, inst['score'])
                    for system_act in inst['system-acts']:
                        if system_act.serialize_args().find('open') > -1:
                            feats[node][val]['open-conf-level-%d'%level] += 1
                            break
                    else:
                        for system_act in inst['system-acts']:
                            if system_act.act_type in ['request', 'expl-conf', 'impl-conf'] and system_act.has_relevant_arg(node):
                                feats[node][val]['cohere-conf-level-%d'%level] += 1
                                break
                        else:
                            feats[node][val]['nocohere-conf-level-%d'%level] += 1

                # Generating affirm act confidence related features                            
                for conf_score in state['observation'][node]['affirm'][val]:
                    feats[node][val]['affirm-level-%d'%_convert_score_to_level(max_level, conf_score)] += 1

                # Generating negate act confidence related features                            
                for conf_score in state['observation'][node]['negate'][val]:
                    feats[node][val]['negate-level-%d'%_convert_score_to_level(max_level, conf_score)] += 1
                    
                # Generating impl-confirm act confidence related features
                if state['observation'][node]['impl-affirm'][val]:
                    feats[node][val]['impl-affirm'] = 1
#                conf_score = state['observation'][node]['impl-affirm'][val]
#                feats[node][val]['impl-affirm-level-%d'%_convert_score_to_level(max_level, conf_score)] += 1

                # Generating canthelp act confidence related features                            
                if state['observation'][node]['canthelp'][val]:
                    feats[node][val]['canthelp'] = 1
                
                # For max-score feature  
                val_score = max([inst['score'] for inst in state['observation'][node]['instance'][val]])
                val_score = max(min(val_score, 1.0), 0.0)
                if val_with_max_score == None or val_with_max_score == val or max_score < val_score:
                    max_score = val_score
                    val_with_max_score = val

                # Generating accumulated-score feature
#                accumulated_score = max([inst['score'] for inst in state['observation'][node]['instance'][val]])
                accumulated_score = sum([inst['score'] for inst in state['observation'][node]['instance'][val]])
                accumulated_score += sum(state['observation'][node]['affirm'][val])
#                accumulated_score += state['observation'][node]['impl-affirm'][val]
                accumulated_score -= sum(state['observation'][node]['negate'][val])
                feats[node][val]['accumulated-score'] = accumulated_score

                # Generating prior feature
                lower_case_val = val.lower() # Since priors are indexed by lower case words
                if lower_case_val in self.priors['nodes'][node]:
                    prior_score = 1.0 * self.priors['nodes'][node][lower_case_val] / self.priors['max-freq-nodes'][node]
                else:
                    prior_score = 0.0
#                if prior_score > self.prior_thlds:
                feats[node][val]['prior-level-%d'%_convert_score_to_level(max_level, prior_score)] = 1

                # Generating bias feature
                feats[node][val]['none-bias'] = 0
#                feats[node][val]['bias'] = 1

            # Generating max-score feature                            
            for val in state['observation'][node]['values']: 
                for level in range(0, max_level):
                    feats[node][val]['max-score-level-%d'%level] = 0
                if val == 'None':
                    continue
                if val_with_max_score != None and val_with_max_score == val:
                    feats[node][val]['max-score-level-%d'%_convert_score_to_level(max_level, max_score)] += 1

            # Make a vector corresponding to the feature                            
            for val in state['observation'][node]['values']: 
                vectors[node][val] = np.zeros(len(feats[node][val]))
                for key in feats[node][val].keys():
                    try:
                        vectors[node][val][self.feat_to_paramidx[node][key] - self.node_paramidx[node][0]] = feats[node][val][key]
                    except KeyError,e:
                        print e
                        print node
                        pprint(self.feat_to_paramidx)
                        print '.'
                        pprint(self.node_paramidx)
                        print 'x'
                        pprint(feats)
                
                if len(feats[node][val]) != len(self.feat_to_paramidx[node]):
                    print len(feats[node][val])
                    print len(self.feat_to_paramidx[node])
#                    pprint(feats[node][val])
                    raise RuntimeError
#                feats[node][val] = self._dump_features(feats[node][val])

        state['features'] = vectors
        state['features-repr'] = feats
        
    
    def _dump_features(self, feature):
        repr = ''
        for i, key in enumerate(sorted(feature.keys())):
            repr += key + ':' + str(feature[key]) + ' '
            if i % 4 == 3:
                repr += '\n'
        return repr
    
    
    def _update_label_state(self, labels, input_hyps):
        state = self.state
        true_user_acts = labels[0]
        false_user_acts = labels[1]
        
        for node in self.nodes:
            for user_act in true_user_acts:
                if user_act.has_relevant_arg(node):
                    state['label'][node] = [user_act.serialize_args()]
#                    label_in_input_hyps = False
#                    for input_hyp in input_hyps:
#                        for user_act in input_hyp.user_acts:
#                            if label == user_act.act_args:
#                                label_in_input_hyps = True
#                                if input_hyp.conf_score > state['label-conf-score'][node]:
#                                    state['label'][node] = [label.serialize_args()]
#                                    state['label-conf-score'][node] = input_hyp.conf_score
#                    if not label_in_input_hyps: # label from gounding value?
#                        state['label'][node] = [label.serialize_args()]
            for user_act in false_user_acts:
                if user_act.has_relevant_arg(node):
                    for label in state['label'][node]:
                        if label == user_act.serialize_args():
                            state['label'][node].remove(user_act.serialize_args())

        

    def get_marginals_and_partition(self, state=None, params=None):
        if state == None: state = self.state
        if params == None: params = self.params
        # dynamically build a state-specific model
        # dm: dynamic model
        dm = self._get_dynamic_model(state, params)
            
        # compute marginals and partition function
        return self.inference_engine.get_marginals_and_partition(dm)

    
    def get_log_likelihood(self, state=None, params=None, zval=None):
        if state == None: state = self.state
        if params == None: params = self.params
            
        # dynamically build a state-specific model
        # dm: dynamic model
        dm = self._get_dynamic_model(state, params)

        return self.inference_engine.get_log_likelihood(dm, state['label'], zval) 
        

    def _get_dynamic_model(self, state, params):
        dm = {}
        dm['nodes'] = deepcopy(self.nodes)
        dm['tied_nodes'] = deepcopy(self.tied_nodes)
        dm['values'] = {}
        dm['edges'] = deepcopy(self.edges)
        dm['rho'] = {} # only for trw
        for edge in dm['edges']:
            dm['rho'][edge] = self.default_rho 
        
        # create potential functions and a global feature vector
        dm['log_ptnt'] = {'nodes':{},'edges':{}}
        dm['potential'] = {'nodes':{},'edges':{}}
        dm['active'] = {}
        dm['label-conf-score'] = {}
        
        for node in dm['nodes']:
            dm['active'][node] = True
            dm['label-conf-score'][node] = 1.0
            dm['values'][node] = state['observation'][node]['values']

            log_ptnt = {}
            potential = {}

            for val in dm['values'][node]: 
#            for val in state['observation'][node]['values']: 
                try:
                    log_ptnt[val] = np.dot(params[self.node_paramidx[node]],
                                                   state['features'][node][val])
                    potential[val] = np.exp(np.dot(params[self.node_paramidx[node]],
                                                   state['features'][node][val]))
                except:
                    print node, val
                    pprint(params[self.node_paramidx[node]])
                    pprint(state['features'][node][val])
                    raise RuntimeError
                
            dm['log_ptnt']['nodes'][node] = log_ptnt
            dm['potential']['nodes'][node] = potential
             
        for edge in dm['edges']:
            dm[edge] = {}
            node1, node2 = edge
            log_ptnt = {}
            potential = {}
            for val1 in state[node1]['values']:
                for val2 in state[node2]['values']:
                    log_ptnt[(val1, val2)] = np.dot(params[self.edge_paramidx[edge]],
                                                              state['features'][edge][(val1,val2)])
                    potential[(val1, val2)] = np.exp(np.dot(params[self.edge_paramidx[edge]],
                                                              state['features'][edge][(val1,val2)]))
            dm['log_ptnt']['edges'][edge] = log_ptnt
            dm['potential']['edges'][edge] = potential
            
        return dm
    
