
#===============================================================================
# Concept network for belief tracking
#===============================================================================
# Nodes
concepts = ['route', 'from', 'to', 'date', 'time']

# Edges
relatoins = [('route','from'), ('route','to'), ('from','to')]
