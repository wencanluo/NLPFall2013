
from pprint import pprint, pformat
from copy import deepcopy

class UserAction(object):
    def __init__(self, act_type, act_args):
        self.act_type = act_type
        self.act_args = act_args
        # for off-line belief tracking on DSTC dataset
        self.slots = act_args#.items()

    def serialize_args(self):
        return '&'.join([str(self.act_args[k]) for k in sorted(self.act_args.keys())])
#        return '&'.join([k + '=' + str(self.act_args[k]) for k in sorted(self.act_args.keys())])
        
    def has_relevant_arg(self, key):
        for arg in self.act_args.keys():
            if arg.startswith(key):
                return True
        return False
    
    def __str__(self):
        return self.act_type + pformat(self.act_args)
        

class InputHypothesis(object):
    def __init__(self, user_acts, conf_score):
        self.user_acts = user_acts
        self.conf_score = conf_score

    def __str__(self):
        return '\n'.join([str(user_act) + str(self.conf_score) for user_act in self.user_acts]) 
                   
                   
class SystemAction(object):
    def __init__(self, act_type, act_args, nlg_args={}, asr_config='', tts_config='', priority=0, side_effect=None):
        self.act_type = act_type
        self.act_args = act_args
        self.priority = priority
        self.asr_config = asr_config
        self.nlg_args = nlg_args
        self.tts_config = tts_config
        self.side_effect = side_effect
        
    def serialize_args(self):
        return '&'.join([str(self.act_args[k]) for k in sorted(self.act_args.keys())])
#        return '&'.join([k + '=' + str(self.act_args[k]) for k in sorted(self.act_args.keys())])

    def has_relevant_arg(self, key):
        for arg in self.act_args.keys():
            if arg.startswith(key):
                return True
        return False
    
    def __str__(self):
        return self.act_type + pformat(self.act_args) 


class Method(object):
    def __init__(self, type, name):
        self.type = type
        self.name = name
        self.plan = None
        self.priority = 0
        self.custom_check_precondition = self._default_check_precondition
        self.custom_check_completion = self._default_check_completion
        self.custom_get_subtasks = self._default_get_subtasks
        self.custom_update_state = self._default_update_state
        self.custom_generate_system_act = None
        
    def check_precondition(self, state):
        return self.custom_check_precondition(state)
    
    def get_subtasks(self, state):
        return self.custom_get_subtasks(state)
    
    def get_new_state(self, state):
        new_state = deepcopy(state)
        self.custom_update_state(new_state)
        return new_state
    
    def check_completion(self, state):
        return self.custom_check_completion(state)
    
    def generate_system_act(self, state):
        return self.custom_generate_system_act(state)
    
    def _default_check_precondition(self, state):
#        if self.type == 'atomic' and state.method_execution_state[self.name] in ['in_execution', 'completed']:
#            return False
        return True
    
    def _default_get_subtasks(self, state):
#        if self.type == 'composite':
#            for subtask in self.custom_subtasks:
#                for method in domain_tasks.task_to_methods[subtask]:
#                    if state.method_execution_state[method] == 'completed':
#                        break
#                else:
        return []

    def _default_update_state(self, state):
        return state
    
    def _default_check_completion(self, state):
        return state.get_plan_execution_state(self.name)    
    
    def __str__(self):
        return self.name + '(' + self.type  + ')'


class Plan(object):
    def __init__(self, type, name, method=None):
        self.type = type
        self.name = name
        self.method = method
        if method != None:
            method.plan = self
        self.parent = None
        self.children = []
    
    def add_child(self, child):
        self.children.append(child)
        child.parent = self
    
    def get_next_actions(self):
        if self.type == 'method' and self.method.type == 'atomic':
            return [self]
        
        actions = []
        for child in self.children:
            actions.extend(child.get_next_actions())
        
        return actions 
    
    def _print_plan(self):
        if len(self.children) == 0:
            return [self.name + '(' + self.type  + ')']
        
        self_strs = []
        for child in self.children:
            for child_str in child._print_plan():
                self_strs.append(self.name + '(' + self.type  + ')'+'->'+child_str)
            
        return self_strs
        
    def __str__(self):
        return '\n'.join(self._print_plan())
