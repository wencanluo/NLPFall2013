
from pprint import pprint, pformat
from copy import deepcopy
import logging
import email_log
import domain.domain_tasks as domain_tasks
from dialog_core.dialog_datatype import Method, Plan


app_logger = logging.getLogger('DialogPlanner')


class DialogPlanner(object):
    def __init__(self):
        # logging
        self.processed_tasks = {}
    
    def plan(self, state):
        tasks = domain_tasks.main_tasks
        
        # Try to find a plan that accomplishes tasks in state. 
        # If successful, return the plan. Otherwise return False.
        plan = self._find_plan(state, tasks)
       
        return plan
    
    def _find_plan(self, state, tasks):
        if tasks == []:
            app_logger.info('END')
            return Plan(type='task', name='empty')
        
        task = tasks[0][0]
        app_logger.info('Working on %s'%task)
        
        assert task in domain_tasks.task_to_methods
        
        task_step = Plan(type='task', name=task)
        methods = domain_tasks.task_to_methods[task]
        for method in methods:
            if method.check_precondition(state):
                method_step = Plan(type='method', name=method.name, method=method)
                if method.type == 'atomic':
                    subtasks = []
                elif method.type == 'composite':
                    subtasks = method.get_subtasks(state)
                subplan = self._find_plan(method.get_new_state(state), subtasks+tasks[1:])
                method_step.add_child(subplan)
                task_step.add_child(method_step)
            else:
                app_logger.info('Method %s does not satisfy preconditions'%method.name)
                    
        app_logger.info('End of %s'%task)
        return task_step
