

import logging
from pprint import pprint, pformat
import copy
import domain.domain_tasks as domain_tasks
from dynamic_crf_tracker.dynamic_crf_tracker import DynamicCRFTracker

app_logger = logging.getLogger('BeliefState')

class BeliefState(object):
    def __init__(self):
        
        self.concepts = {}
        self.tracker = DynamicCRFTracker(domain_tasks.concepts, model_path=domain_tasks.model_path, prior_model_path=domain_tasks.prior_model_path)
        self.init()
        
        
    def init(self):
        for concept in domain_tasks.concepts:
            self.concepts[concept] = {'hyps': []}

        self.tracker.init_tracker_state()
        
        
    def update_belief(self, dialog_state):
#        system_act = [dialog_state.history_system_acts[-1]]
        system_acts = dialog_state.system_acts_current_turn
        input_hyps = dialog_state.history_input_hyps[-1]
        
        marginals, zval, reps = self.tracker.update(system_acts, input_hyps)
        
        for concept in domain_tasks.concepts:
            self.concepts[concept] = {'hyps': []}

        for concept in marginals.keys():
            for val in marginals[concept].keys():
                if val != 'None' and marginals[concept][val] > 0:
                    self.concepts[concept]['hyps'].append({'value': val, 'score': marginals[concept][val]})
            self.concepts[concept]['hyps'].sort(key=lambda x: x['score'], reverse=True)
                        
        # need to construct joint here
        
        app_logger.info(pformat(self.concepts))