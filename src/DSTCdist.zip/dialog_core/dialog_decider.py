
class DialogDecider(object):
    def __init__(self):
        pass

    def _get_priority_by_act_priority_and_order_in_recipe(self, state, actions):    
        return [act.priority - i for i, act in enumerate(actions)]
    
    def get_priority(self, *a):
        return self._get_priority_by_act_priority_and_order_in_recipe(*a)