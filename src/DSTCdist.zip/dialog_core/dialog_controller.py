
import time
import pprint
from datetime import datetime
from copy import deepcopy
from global_config import *
from dialog_state import DialogState
from dialog_actuator import DialogActuator
from dialog_planner import DialogPlanner 
from dialog_decider import DialogDecider 
import domain.domain_semantics as domain_semantics
import logging
import email_log


app_logger = logging.getLogger('DialogController')


class DialogController(object):
    #===========================================================================
    # Inits
    #===========================================================================
    def __init__(self, session_id, out_queue, result_queue):
        #
        # load configs
        #
        self.config = get_config()

        self.continue_dialog = True

        # create dialog state, actuator and belief tracker
        self.dialog_state = DialogState(session_id)
        self.dialog_planner = DialogPlanner()
        self.dialog_decider = DialogDecider()
        self.dialog_actuator = DialogActuator(out_queue, result_queue)
        
        # load domain specifications
        self.parse_input_hyps = domain_semantics.parse_input_hyps
        
        app_logger.info('Dialog controller created')
        
        
    #===========================================================================
    # Dialog processing consists of four tasks;
    # 1. updating state
    # 2. planning action agenda 
    # 3. choosing the best action
    # 4. executing the action
    #===========================================================================
    def dialog_processing(self, frame):
        # updating state
        app_logger.info('Begin to update dialog state') 
        self._update_state_for_event(frame)
        app_logger.info('Complete updating dialog state')
        
        if self._need_performing_action():
            while True:
#                if self._need_planning():
                # planning: get a set of possible system actions given the state
                app_logger.info('Begin to plan dialog actions') 
                self._plan()
                app_logger.info('Complete planning dialog actions')
        
                next_actions = self._get_next_executable_actions(self.plan)
                # choosing the best action
                if next_actions != []:
                    app_logger.info('Begin to choose dialog action') 
                    next_action = self._choose_action(next_actions)
                    self._update_state_for_output(next_action)
                    app_logger.info('Complete choosing dialog action')
                else:
                    break
                
                # execution
                app_logger.info('Begin to execute dialog action') 
                self.dialog_actuator.execute(self.dialog_state, self.dialog_state.history_system_acts[-1])
                app_logger.info('Complete execution of dialog action')
                
                if self._stop_dialog_processing():
                    break
            
        self.dialog_actuator.send_wait_event_message()


    def _need_performing_action(self):
        if self.dialog_state.last_event_type == None:
            return True
        if self.dialog_state.last_event_type == 'begin_session':
            return True
        if self.dialog_state.last_event_type == 'user_utterance_end':
            return True
        if self.dialog_state.last_event_type == 'turn_timeout':
            return True
        if self.dialog_state.last_event_type == 'system_utterance_end':
            if len(self.dialog_state.history_system_acts) == 0:
                return True
            system_act = self.dialog_state.history_system_acts[-1]
            if system_act.nlg_args != {} and system_act.nlg_args['type'] == 'inform':
#            if system_act.nlg_args == {} or system_act.nlg_args['type'] not in ['request', 'expl-conf']:
                return True
        return False

        
    def _need_planning(self):
        # check if it is right time for planning
        if self.dialog_state.last_event_type == None:
            return True
        if self.dialog_state.last_event_type == 'begin_session':
            return True
        if self.dialog_state.last_event_type == 'user_utterance_end':
            return True
        if self.dialog_state.last_event_type == 'turn_timeout':
            return True
        if len(self.dialog_state.history_system_acts) == 0:
            return True
        system_act = self.dialog_state.history_system_acts[-1]
        if system_act.act_type == 'execute':
            return True
        return False


    def _stop_dialog_processing(self):
        if len(self.dialog_state.history_system_acts) > 0 and\
        self.dialog_state.history_system_acts[-1].act_type == 'execute':
            return False
        return True
    
    
    def _update_state_for_output(self, next_action):
        self.dialog_state.set_plan_execution_state(next_action.name, True)
        system_act = next_action.generate_system_act(self.dialog_state)
        self.dialog_state.history_system_acts.append(system_act)
        if self.dialog_state.input_hyps_current_turn != []:
            self.dialog_state.input_hyps_current_turn = []
            self.dialog_state.system_acts_current_turn = []
        self.dialog_state.system_acts_current_turn.append(system_act)
        
            
    # update dialog state by incorporating the input frame        
    def _update_state_for_event(self, frame):
        # call event handlers
        if frame.name == 'begin_session':
            event_type = 'begin_session'
            self._begin_session_handler(frame)

        elif frame.name == 'DialogManager.handle_event':
            event_type = frame[':event_type']
            app_logger.info('event_type: %s'%event_type)
            
            if event_type == 'user_utterance_end':
                self._user_utterance_end_handler(frame)
                        
            elif event_type == 'system_utterance_start':
                self._system_utterance_start_handler(frame)
                
            elif event_type == 'system_utterance_end':
                self._system_utterance_end_handler(frame)
                
            elif event_type == 'system_utterance_canceled':
                self._system_utterance_canceled_handler(frame)
                
            elif event_type == 'dialog_state_change':
                self._dialog_state_change_handler(frame)
                
            elif event_type == 'turn_timeout':
                self._turn_timeout_handler(frame)
                    
            else:
                self._unknown_event_handler(frame)

        elif frame.name == 'end_session':
            event_type = 'end_session'
            self._end_session_handler(frame)
    
        # store the event_type in the dialog state, 
        # so we don't need to reference the frame later
        self.dialog_state.last_event_type = event_type
        
        
    # find out possible actions given the current state
    def _plan(self):
        # call the dialog planner                
        self.plan = self.dialog_planner.plan(self.dialog_state)
        app_logger.info('Plan\n %s'%self.plan)


    def _get_next_executable_actions(self, plan):            
        if plan.type == 'method' and plan.method.type == 'atomic' and not plan.method.check_completion(self.dialog_state):
            return [plan.method]
        
        actions = []
        for child in plan.children:
            actions.extend(self._get_next_executable_actions(child))
        
        return actions 


    # choose the best action among given actions
    # based on MDP or simple rules.
    def _choose_action(self, next_actions):
        from operator import itemgetter
        
        priorities = self.dialog_decider.get_priority(self.dialog_state, next_actions)
        prioritized_next_actions = zip(priorities, next_actions)
        # the higher priority, the more important
        prioritized_next_actions = sorted(prioritized_next_actions, key=itemgetter(0), reverse=True)
        
        # currently, just return the best action
        next_action = prioritized_next_actions[0][1]
        app_logger.info('Chosen action\n %s'%next_action.name)
        
        self.plan = next_action.plan.children[0]
        
        return next_action


    # read a specific state and restart the interaction
    # for instance, greeting can be removed by setting it's done
    def _restart_interaction(self):
        self._init_for_new_query()
        message = {'type':'WAITINTERACTIONEVENT'}
        self.out_queue.put(message)

    
    #===========================================================================
    # Event handlers
    #===========================================================================
    def _begin_session_handler(self, frame):
        app_logger.info('begin_session')
        # store session begin time
        self.dialog_state.session_start_time = time.time()
                
                
    def _user_utterance_end_handler(self, frame):
        app_logger.info('user_utterance_end')
        
        # store the latest user action time
        self.dialog_state.last_input_time = time.time()
        
        # append the parsed results to the history of input hypotheses in the dialog state.
        self.dialog_state.history_input_hyps.append(self.parse_input_hyps(self.dialog_state, self.dialog_actuator, frame))
        
        # append the parsed results to the list of input hypotheses for the current turn.
        self.dialog_state.input_hyps_current_turn.append(self.dialog_state.history_input_hyps[-1])
        
        # update belief states
        self.dialog_state.update_belief()
                
                
    def _system_utterance_start_handler(self, frame):
        app_logger.info('system_utterance_start(%s) %s'%(frame[':properties'][':utt_count'],\
                                                             frame[':properties'][':tagged_prompt']))
        self.dialog_state.last_output_start_time = time.time()
        self.dialog_state.last_output_status = 'start'
        self.dialog_state.bargein = False
        
        
    def _system_utterance_end_handler(self, frame):
        app_logger.info('system_utterance_end(%s)'%frame[':properties'][':utt_count'])
        self.dialog_state.last_output_end_time = time.time()
        self.dialog_state.last_output_status = 'end'
        # check if the user barged in
        if frame[':properties'][':bargein_pos'] != '-1':
            self.dialog_state.bargein = True
            app_logger.info('Barge in detected at %s'%frame[':properties'][':tagged_prompt'])
        if frame[':properties'][':utt_count'] in self.dialog_state.notify_prompts:
            self.dialog_state.notify_prompts.remove(frame[':properties'][':utt_count'])


    def _system_utterance_canceled_handler(self, frame):
        app_logger.info('system_utterance_canceled(%s)'%frame[':properties'][':utt_count'])
        self.dialog_state.last_output_end_time = time.time()
        self.dialog_state.last_output_status = 'canceled'
        # check if the user barged in
        if ':bargein_pos' in frame[':properties'] and frame[':properties'][':bargein_pos'] != '-1':
            self.dialog_state.bargein = True
            app_logger.info('Barge in detected at %s'%frame[':properties'][':tagged_prompt'])


    def _dialog_state_change_handler(self, frame):
        app_logger.info('dialog_state_change')
        # broadcast dialog state
        self.dialog_actuator.broadcast_dialog_state(self.dialog_state)


    def _turn_timeout_handler(self, frame):
        app_logger.info('turn_timeout')
#        self.id_suffix += 1
#        self.asrResult = ASRResult.FromHelios([UserAction('non-understanding')],[1.0])
#        app_logger.info('ASRResult: %s'%str(self.asrResult))


    def _unknown_event_handler(self, frame):
        app_logger.info('Unknow event')


    def _end_session_handler(self, frame):
        app_logger.info('end_session')
        # respond to end session message (should we?)
        self.dialog_actuator.reply_end_session()
        self.continue_dialog = False




