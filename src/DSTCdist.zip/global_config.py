'''
A module for globally sharing ConfigParser objects.
For more information, see the Python module ConfigParser.

sungjin.lee@cs.cmu.edu
'''

from ConfigParser import ConfigParser

_GLOBAL_CONFIG = None

def init_config():
    global _GLOBAL_CONFIG
    assert (_GLOBAL_CONFIG == None), 'InitConfig has already been called.'
    _GLOBAL_CONFIG = ConfigParser()
    _GLOBAL_CONFIG.optionxform = str

def get_config():
    global _GLOBAL_CONFIG
    return _GLOBAL_CONFIG
