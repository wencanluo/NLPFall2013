import sys, os, subprocess

subprocess.call("python ../dynamic_crf_tracker/offline_tracker.py --dataset=train3.half2 --dataroot=D:/Work/DSTC/dstc_data/ --asrmode=live --trackfile=../log/dcrf-track-tr3.json --haslabel=yes", shell=True)
subprocess.call("python ../dstc/score.py --dataset=train3.half2 --dataroot=D:/Work/DSTC/dstc_data/ --trackfile=../log/dcrf-track-tr3.json --scorefile=../log/dcrf-score-tr3.csv", shell=True)
subprocess.call("python ../dstc/report.py --scorefile=../log/dcrf-score-tr3.csv --reportfile=../log/dcrf-report-tr3.txt", shell=True)

