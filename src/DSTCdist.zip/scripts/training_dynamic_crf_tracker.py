
import dynamic_crf_tracker.dynamic_crf_trainer as dcrf

# build prior model
dcrf.generate_dataset('train3.half1', 'D:/Work/DSTC/dstc_data', 'D:/Projects/DSTC_data/train3.half1.nofeat.st', feature_extraction=False)
dcrf.generate_prior_model('../dynamic_crf_tracker/model/3-1-prior.model', ['D:/Projects/DSTC_data/train3.half1.nofeat.st'])

# build tracker model
dcrf.generate_dataset('train3.half1', 'D:/Work/DSTC/dstc_data', 'D:/Projects/DSTC_data/train3.half1.st', '../dynamic_crf_tracker/model/3-1-prior.model')
dcrf.train_batch('../dynamic_crf_tracker/model/3-1.model', ['D:/Projects/DSTC_data/train3.half1.st'])


